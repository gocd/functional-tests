package org.jruby.ast;

/**
 * Marker interface for nodes invisible to IDE consumers
 */
public interface InvisibleNode {}
