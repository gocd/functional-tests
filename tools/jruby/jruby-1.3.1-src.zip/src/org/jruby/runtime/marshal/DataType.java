package org.jruby.runtime.marshal;

/**
 *
 * DataType is similiar to T_DATA to represent types which are incapable of getting
 * marshalled.  This is just a marker interface.
 */
public interface DataType {
}
